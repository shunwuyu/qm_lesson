class Barrage {
  constructor(obj, ctx) {
    
  }
}