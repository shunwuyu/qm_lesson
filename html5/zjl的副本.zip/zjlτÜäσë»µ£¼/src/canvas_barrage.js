class CanvasBarrage {
  constructor(canvas, video, opts = {}) { 
    console.log('初始化');
  }
}

export default CanvasBarrage;