import CanvasBarrage from './canvas_barrage'

const canvasBarrage = new CanvasBarrage();

console.log(canvasBarrage);