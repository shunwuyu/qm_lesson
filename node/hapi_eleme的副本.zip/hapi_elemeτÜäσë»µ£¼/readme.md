Swagger API文档 UI框架
API 是开发工作中的一环， hapi-swagger 将API 开发融合进代码之中。 
前后端分离开发， 依赖文档来交流。 
现代开发中， 项目越来越大， 用户越来越多， 用户体验越来越重要， 前端React/VUE 独立开发，
后端不再负责整体项目架构， 以提供API 为主
文档亦是代码， 以plugin的方式接入，
register 到app.js /documentation 
只要在每个route 里配置一下