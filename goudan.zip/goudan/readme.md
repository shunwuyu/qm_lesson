广告 复用性
抽成一个模版 
components 两种 
简单 wxml wxss    抽离一部分的界面  components

复杂 Component  js property  data  