// pages/videos/videos.js
const util = require('../../utils/util.js')
const movieUrl =  getApp().globalData.movieBase
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initSwiper();
    // movie list 
    this.getList('down');
  },
  initSwiper() {

  },
  getList () {
    util.$get(`${movieUrl}/api/v2/article`, { app_id: 6, cid: 4, article_id: 0 })
    .then(res => {
      if (res.data.status === 0) {
        let swiperList = res.data.data.articles.map(v => {
          return { // 转换一下时间
            create_time: v.create_time = util.formatTime(new Date(v.create_time), 'yyyy-MM-dd'),
            article_id: v.article_id,
            title: v.title,
            content: v.content,
            video_src: v.videos[0].video_src,
            thumbnails: v.thumbnails[0].url
          }
        })
        this.setData({
          swiperList
        })
      }
    }).catch(e => {
      wx.showToast({ title: `网络错误!`, duration: 1000, icon: "none" })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})