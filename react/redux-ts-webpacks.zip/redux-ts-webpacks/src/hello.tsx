import * as React from 'react';

export const HelloComponent = () => {
  return (
    <h2>Hello Component!</h2>
  )
}