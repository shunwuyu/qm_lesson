import * as React from 'react';
// 没用state
export const MembersPage: React.StatelessComponent<{}> = () => {
  return (
    <div className="row">
      <h2>Memebers Page</h2>
    </div>
  )
}