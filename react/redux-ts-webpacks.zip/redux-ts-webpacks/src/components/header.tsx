import * as React from 'react';

export const Header: React.StatelessComponent<{}> = () => {
  return (
    <div className="row">
      <h2>Application Header</h2>
    </div>
  )
}
